## Scope
`[Add context about what this feature is about and explain why of the feature and your technical decisions.]`



- [ ] `[Sub task]`


### Screenshots
---


## Code improvements
- `[Did you add some generic like utility, component, or anything else useful outside of this PR]`


### Developer checklist
- [ ] I’ve manually tested that code works locally on desktop and mobile browsers.
- [ ] I’ve reviewed my code.
- [ ] I’ve removed all my personal credentials (API keys etc.) from the code.